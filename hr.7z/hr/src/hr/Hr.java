


package hr;

import java.util.Scanner;

class employee{

private String firstname,email,lastname,String,address ;
private int age;

    public employee(String firstname, String email, String lastname,String address , int age ) {
        this.firstname = firstname;
        this.email = email;
        this.lastname = lastname;
      this.address= address;
        this.age = age;
       
    }}
class programer extends employee{

    public programer(java.lang.String firstname, java.lang.String email, java.lang.String lastname, java.lang.String address, int age) {
        super(firstname, email, lastname, address, age);
        System.out.println("programer: ");
        System.out.println( "the first name: "+firstname);
        System.out.println( "the last name: "+lastname);
        System.out.println( "the email: "+email);
        System.out.println( "the age: "+age);
        System.out.println( "the address: "+address);
        
        
        
        
        
        
        
        
    }

 







}


class worker extends employee{

    public worker(java.lang.String firstname, java.lang.String email, java.lang.String lastname, java.lang.String address, int age) {
        super(firstname, email, lastname, address, age);
                System.out.println("worker: ");
        System.out.println( "the first name: "+firstname);
        System.out.println( "the last name: "+lastname);
        System.out.println( "the email: "+email);
        System.out.println( "the age: "+age);
        System.out.println( "the address: "+address);
        
        
    }
}

public class Hr {

    
    
    
    
   
    public static void main(String[] args) {
           
        Scanner x=new Scanner(System.in);
           System.out.println("for worker enter (w) for programer enter (p) :");
        String s=x.nextLine();
     
        switch(s){
            case "w":
      employee ob=new worker("hashm", "hasmabas@gmail.com","abas", " sulemany",35);
       break;
            case "p" : 
     employee obj=new programer("muhamad", "muhamadabas@gmail.com","abas", " sulemany",28);
       
        break;
        
        
        
        }
        
        
    }











}
    

